const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 3000;

// Create a MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root', 
  password: '', 
  database: 'piggy_bank'
});

// Connect to MySQL
connection.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL');
  }
});

// Middleware to parse JSON requests
app.use(bodyParser.json());

// API endpoint to get all transactions
app.get('/api/transactions', (req, res) => {
  const sql = 'SELECT * FROM transactions';

  connection.query(sql, (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

// API endpoint to add a new transaction
app.post('/api/transactions', (req, res) => {
  const { type, amount } = req.body;
  const sql = 'INSERT INTO transactions (type, amount) VALUES (?, ?)';
  const values = [type, amount];

  connection.query(sql, values, (err, result) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      const newTransaction = { id: result.insertId, type, amount };
      res.status(201).json(newTransaction);
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
