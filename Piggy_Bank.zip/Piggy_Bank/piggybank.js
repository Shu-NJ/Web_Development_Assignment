
let piggyBankActive = false;
let savings = 0;
let transactions = [];

function deposit() {
    if (!piggyBankActive) {
        alert("You need to start a new piggy bank first");
        return;
    }

    const amountInput = document.getElementById("amount");
    const amount = parseFloat(amountInput.value);

    if (isNaN(amount) || amount <= 0) {
        alert("Please enter a valid positive amount.");
        return;
    }

    savings += amount;
    transactions.push({ type: "Deposit", amount });

    
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:3000/api/items", true);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 201) {
            console.log("Transaction recorded successfully.");
        }
    };

    const data = JSON.stringify({ name: "Deposit", description: amount });
    xhr.send(data);

    updateSavings();
    updateTransactionHistory();
    amountInput.value = "";
}

function breakPiggyBank() {
    if (!piggyBankActive) {
        alert("There is no piggy bank to break");
        return;
    }

    const withdrawnAmount = savings;
    savings = 0;
    transactions.push({ type: "Break Piggy Bank", amount: withdrawnAmount });
    updateSavings();
    updateTransactionHistory();
    alert(`You broke the piggy bank and withdrew $${withdrawnAmount.toFixed(2)}`);
    piggyBankActive = false;
}

function startNewPiggyBank() {
    if (piggyBankActive) {
        alert("You need to break the current piggy bank first");
        return;
    }

    piggyBankActive = true;
    savings = 0;
    transactions = [];
    updateSavings();
    updateTransactionHistory();
    alert("You started a new piggy bank");
}

function updateSavings() {
    const savingsElement = document.getElementById("savings");
    savingsElement.textContent = savings.toFixed(2);
}

function updateTransactionHistory() {
    const transactionList = document.getElementById("transactionList");
    transactionList.innerHTML = '';

    for (const transaction of transactions) {
        const transactionItem = document.createElement("li");
        transactionItem.textContent = `${transaction.type}: $${transaction.amount.toFixed(2)}`;
        transactionList.appendChild(transactionItem);
    }
}
